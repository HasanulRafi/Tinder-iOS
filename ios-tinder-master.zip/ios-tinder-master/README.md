# ios-tinder
Tinder app for Codepath

<img src='ryan-swipe-right.gif' title='Video Walkthrough' width='' alt='Video Walkthrough' />
<img src='ryan-swipe-left.gif' title='Video Walkthrough' width='' alt='Video Walkthrough' />

Like you'd ever swipe left on Ryan Gosling...
